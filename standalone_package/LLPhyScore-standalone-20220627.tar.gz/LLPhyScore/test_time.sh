#!/bin/bash
 
start=$(date +%s)

python3 Predictor2_standalone.py -i example.fasta -m human+PDB

end=$(date +%s)
take=$(( end - start ))
echo Time taken to execute commands is ${take} seconds.
