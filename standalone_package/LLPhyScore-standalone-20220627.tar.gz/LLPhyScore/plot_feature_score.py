"""Script to generate feature-based heatmap plots for input fasta file."""

import os
import sys

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


# Step 1: Run LLPhyScore_standalone.py on input fasta file and save feature-based score results. 
def calc_feature_based_scores(input_fasta, output_csv="output.csv"):
    os.system("python3 LLPhyScore_standalone.py -i {} -s residue_level -o {}".format(input_fasta, output_csv))


# Step 2: Plot the feature-based score results.
def plot_res_score_heatmap(result_df, tag):
    """plot residue-level score heatmap for one tag."""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6), gridspec_kw={'height_ratios': [1, 6]})
    # plot sum score
    sum_df = result_df[result_df.feature=='8-feature sum'].copy()
    plot_sum_df = sum_df.loc[sum_df.tag==tag].copy()
    plot_sum_df = plot_sum_df.pivot("feature", "residue_idx", "score")
    g = sns.heatmap(plot_sum_df, cmap='coolwarm_r', ax=ax1, vmin=-4, vmax=4)
    ax1.set_xticks([])
    ax1.set_xlabel('')
    ax1.set_ylabel('')
    
    # plot separate score
    sep_df = result_df[result_df.feature!='8-feature sum'].copy()
    plot_sep_df = sep_df.loc[sep_df.tag==tag].copy()
    plot_sep_df = plot_sep_df.pivot("feature", "residue_idx", "score")
    g = sns.heatmap(plot_sep_df, cmap='coolwarm_r', ax=ax2, vmin=-1, vmax=1)
    g.tick_params(left=True, bottom=False)
    ax1.set_title('{}, scores along sequence'.format(tag))
    fig.tight_layout()

    return fig
    

def plot_feature_based_scores(score_csv="output.csv"):
    """plot residue-level score heatmap for all tags."""
    # load scoring result.
    residue_scoring_result = pd.read_csv(score_csv)
    # get distinct tags.
    test_tags = residue_scoring_result.tag.unique().tolist()
    for tag in test_tags:
        # plot each tag.
        fig = plot_res_score_heatmap(result_df=residue_scoring_result,
                                     tag=tag)
        # save each plot as figure.
        fig.savefig("{}_feature_based_scores.png".format(tag), dpi=300)

def main():
    # reads argument - input fasta filename.
    fasta_file = sys.argv[1]
    # calculates and saves feature-based score results.
    calc_feature_based_scores(input_fasta=fasta_file)
    # plot feature-based residue-level scores for all sequences in the fasta file.
    plot_feature_based_scores()

if __name__ == "__main__":
    main()