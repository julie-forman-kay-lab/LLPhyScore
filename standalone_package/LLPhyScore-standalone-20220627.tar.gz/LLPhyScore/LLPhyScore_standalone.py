"""
This is the module where a pretrained ML model is loaded to calculate the phase separation probability of any given
sequence or fasta file."""
import argparse
import pickle
import sys
from os.path import exists
from pathlib import Path
from math import sqrt

import numpy as np
import pandas as pd
pd.set_option('display.max_columns', None)
pd.set_option("display.max_rows", None)
pd.set_option('display.width', 1000)

from scipy.stats import percentileofscore
from tqdm import tqdm


##################################
# LLPhyScore's parameters
##################################

# score database path.
score_db_dir = './ScoreDBs'

# final models using different weights.
final_models = {
    # weight trained against PDB.
    'PDB': pickle.load(open(score_db_dir+'/trained_weights.8FEATURES.{}.pkl'.format('PDB'), 'rb')),
    # weight trained against human.
    'human': pickle.load(open(score_db_dir+'/trained_weights.8FEATURES.{}.pkl'.format('human'), 'rb')), 
    # weight trained against human+PDB.
    'human+PDB': pickle.load(open(score_db_dir+'/trained_weights.8FEATURES.{}.pkl'.format('human+PDB'), 'rb')), 
}

# grid2weight scores of human proteome using different weights.
human_g2w_scores = {
    # weight trained against PDB.
    'PDB': pd.read_csv(score_db_dir+'/human_g2w_scores_using_{}weight.csv'.format('PDB')),
    # weight trained against human.
    'human': pd.read_csv(score_db_dir+'/human_g2w_scores_using_{}weight.csv'.format('human')),
    # weight trained against human+PDB.
    'human+PDB': pd.read_csv(score_db_dir+'/human_g2w_scores_using_{}weight.csv'.format('human+PDB')),
}

# grid2weight scores of PDB proteome using different weights.
PDB_g2w_scores = {
    # weight trained against PDB.
    'PDB': pd.read_csv(score_db_dir+'/PDB_g2w_scores_using_{}weight.csv'.format('PDB')),
    # weight trained against human.
    'human': pd.read_csv(score_db_dir+'/PDB_g2w_scores_using_{}weight.csv'.format('human')),
    # weight trained against human+PDB.
    'human+PDB': pd.read_csv(score_db_dir+'/PDB_g2w_scores_using_{}weight.csv'.format('human+PDB')),
}

# grid2weight scores of human+PDB proteome using different weights.
humanPDB_g2w_scores = {
    # weight trained against PDB.
    'PDB': pd.concat([human_g2w_scores['PDB'], PDB_g2w_scores['PDB']]).reset_index(drop=True),
    # weight trained against human.
    'human': pd.concat([human_g2w_scores['human'], PDB_g2w_scores['human']]).reset_index(drop=True),
    # weight trained against human+PDB.
    'human+PDB': pd.concat([human_g2w_scores['human+PDB'], PDB_g2w_scores['human+PDB']]).reset_index(drop=True),
}

# features in the predictor.
features = [
    'protein-water',
    'protein-carbon',
    'hydrogen bond (long-range)',
    'pi-pi (long-range)',
    'disorder (long)',
    'K-Beta similarity',
    'disorder (short)',
    'electrostatic (short-range)',
    '8-feature sum'
]

# mean and std of PDB grid2weight scores.
# g2w_mean_std_pdb = {
#     'protein-water': [15.744568408690546, 23.788728525299224],
#     'protein-carbon': [12.231356429829713, 21.37268551420418],
#     'hydrogen bond (long-range)': [-37.484145625367, 25.7010409855839],
#     'pi-pi (long-range)': [-23.827363476218437, 23.902767365537166],
#     'disorder (long)': [-72.12566059894304, 44.19872429991269],
#     'K-Beta similarity': [-68.38637698179683, 41.80327864064934],
#     'disorder (short)': [-8.697886083382267, 19.39892759937557],
#     'electrostatic (short-range)': [56.95948326482678, 32.86768029293569],
#     '8-feature sum': [-125.58602466236054, 111.98947440415908]
# }
g2w_means_stds_PDB = {
    'PDB': pd.DataFrame([PDB_g2w_scores['PDB'].mean(), PDB_g2w_scores['PDB'].std()]).to_dict('list'),
    'human': pd.DataFrame([PDB_g2w_scores['human'].mean(), PDB_g2w_scores['human'].std()]).to_dict('list'),
    'human+PDB': pd.DataFrame([PDB_g2w_scores['human+PDB'].mean(), PDB_g2w_scores['human+PDB'].std()]).to_dict('list'),
}

# mean and std of human proteome's grid2weight scores.
# g2w_mean_std_human = {
#     'protein-water': [42.52871530336527, 91.19030598460962],
#     'protein-carbon': [83.90940800786048, 133.53250829944298],
#     'hydrogen bond (long-range)': [-36.17548513878654, 79.02804262059375],
#     'pi-pi (long-range)': [-32.28268238761975, 67.7022731625005],
#     'disorder (long)': [-78.70223532301645, 112.28850683500332],
#     'K-Beta similarity': [-99.96914762957505, 119.9427950317118],
#     'disorder (short)': [0.9140260378285433, 60.79791636116328],
#     'electrostatic (short-range)': [135.33402112503072, 162.02355267012032],
#     '8-feature sum': [15.556619995087202, 422.09175962933824]
# }
g2w_means_stds_human = {
    'PDB': pd.DataFrame([human_g2w_scores['PDB'].mean(), human_g2w_scores['PDB'].std()]).to_dict('list'),
    'human': pd.DataFrame([human_g2w_scores['human'].mean(), human_g2w_scores['human'].std()]).to_dict('list'),
    'human+PDB': pd.DataFrame([human_g2w_scores['human+PDB'].mean(), human_g2w_scores['human+PDB'].std()]).to_dict('list'),
}

g2w_means_stds_humanPDB = {
    'PDB': pd.DataFrame([humanPDB_g2w_scores['PDB'].mean(), humanPDB_g2w_scores['PDB'].std()]).to_dict('list'),
    'human': pd.DataFrame([humanPDB_g2w_scores['human'].mean(), humanPDB_g2w_scores['human'].std()]).to_dict('list'),
    'human+PDB': pd.DataFrame([humanPDB_g2w_scores['human+PDB'].mean(), humanPDB_g2w_scores['human+PDB'].std()]).to_dict('list'),
}

# sr/lr tag meanings (16 features) for 8 physical factors.
feature_tagABs = {
    "S2.SUMPI": ["srpipi", "lrpipi"],
    "S3.WATER.V2": ["Water", "Carbon"],
    "S4.SSPRED": ["ssH", "ssE", "ssL"],
    "S5.DISO": ["disL", "disS"],
    "S6.CHARGE.V2": ["srELEC", "lrELEC"],
    "S7.ELECHB.V2": ["sr_hb", "lr_hb"],
    "S8.CationPi.V2": ["srCATPI", "lrCATPI"],
    "S9.LARKS.V2": ["larkSIM", "larkFAR"]
}

feature_tagABs_new = {
    "S2.SUMPI": ['pi-pi (short-range)', 'pi-pi (long-range)'],
    "S3.WATER.V2": ['protein-water', 'protein-carbon'],
    "S4.SSPRED": ['sec. structure (helices)', 'sec. structure (strands)'],
    "S5.DISO": ['disorder (long)', 'disorder (short)'],
    "S6.CHARGE.V2": ['electrostatic (short-range)', 'electrostatic (long-range)'],
    "S7.ELECHB.V2": ['hydrogen bond (short-range)', 'hydrogen bond (long-range)'],
    "S8.CationPi.V2": ['cation-pi (short-range)', 'cation-pi (long-range)'],
    "S9.LARKS.V2": ['K-Beta similarity', 'K-Beta non-similarity']
    }

# signs +/- for 16 sub-features.
feature_signs = {
    'pi-pi (short-range)': 1,
    'pi-pi (long-range)': 1,
    'protein-water': 1,
    'protein-carbon': -1,
    'sec. structure (helices)': -1,
    'sec. structure (strands)': 1,
    'disorder (long)': 1,
    'disorder (short)': 1,
    'electrostatic (short-range)': 1,
    'electrostatic (long-range)': -1,
    'hydrogen bond (short-range)': 1,
    'hydrogen bond (long-range)': 1,
    'cation-pi (short-range)': -1,
    'cation-pi (long-range)': -1,
    'K-Beta similarity': 1,
    'K-Beta non-similarity': -1
}


# canonical amino acids.
canonical_amino_acids = {'A': 0, 'R': 0, 'N': 0, 'D': 0, 'C': 0,
                         'E': 0, 'Q': 0, 'G': 0, 'H': 0, 'I': 0,
                         'L': 0, 'K': 0, 'M': 0, 'F': 0, 'P': 0,
                         'S': 0, 'T': 0, 'W': 0, 'Y': 0, 'V': 0}

######################################
# Utility functions
######################################
def grid2weight_score_sub_feature(one_feature_grid, one_feature_weight, sub_feature, sign=1):
    """Calculate the grid2weight score for one out of 16 sub-features.

    Args:
        one_feature_grid (dict): the "grid" calculated from sequence for one feature
        one_feature_weight (dict): the "weight" for one feature.
        sub_feature (int): 0/1, indicating which "sub-feature" to use 
        sign (int, optional): sign of a subfeature. Defaults to 1.

    Returns:
        [int]: grid2weight score for a sub-feature.
    """
    sum_score = 0
    if sub_feature == 0:
        for aa in one_feature_grid.keys():
            sum_score += np.where(one_feature_grid[aa][1] > one_feature_weight[aa][0], 1, 0).sum()
            sum_score -= np.where(one_feature_grid[aa][1] < one_feature_weight[aa][1], 1, 0).sum()
    else:
        for aa in one_feature_grid.keys():
            sum_score += np.where(one_feature_grid[aa][2] > one_feature_weight[aa][2], 1, 0).sum()
            sum_score -= np.where(one_feature_grid[aa][2] < one_feature_weight[aa][3], 1, 0).sum()
    return sum_score*sign


def grid2weight_score_residue_level_sub_feature(one_feature_grid, one_feature_weight, sub_feature, sign=1):
    """g2w scores along sequence for sub-feature."""
    residue_scores = {'res_type':[], 'res_idx':[], 'res_score': []}
    for aa in one_feature_grid.keys():
        res_len = one_feature_grid[aa].shape[1] # length of this residue's grid.
        res_types = [aa]*res_len
        res_idxs = one_feature_grid[aa][0, :].astype(int).tolist()
        tagA_reward = np.where(one_feature_grid[aa][1] > one_feature_weight[aa][0], 1, 0)
        tagA_penali = np.where(one_feature_grid[aa][1] < one_feature_weight[aa][1], 1, 0)
        tagB_reward = np.where(one_feature_grid[aa][2] > one_feature_weight[aa][2], 1, 0)
        tagB_penali = np.where(one_feature_grid[aa][2] < one_feature_weight[aa][3], 1, 0)
        tagA_scores = ((tagA_reward - tagA_penali)*sign).tolist()
        tagB_scores = ((tagB_reward - tagB_penali)*sign).tolist()
        res_scores = tagA_scores if sub_feature==0 else tagB_scores
        
        # update residue_scores.
        residue_scores['res_type'] += res_types
        residue_scores['res_idx'] += res_idxs
        residue_scores['res_score'] += res_scores

    # deal with edge case - empty residue_scores.
    if len(residue_scores['res_idx'])==0:
        return residue_scores

    # sort lists based on res_idx.
    residue_scores['res_idx'], \
    residue_scores['res_type'], \
    residue_scores['res_score'] = zip(*sorted(zip(residue_scores['res_idx'],
                                                    residue_scores['res_type'],
                                                    residue_scores['res_score'])))
    return residue_scores


def just_canonical(seq):
    """Function to load sequence and make sure all amino acids are canonical."""
    for n in range(len(seq)):
        if not (seq[n] in canonical_amino_acids):# and seq[n]!='U':
            # print(seq[n])
            return False
    return True


def make_linekey(zscore):
    """Function to round up/down zscores. This is a function needed by the GridScore class to calculate statistics."""
    round_z = round(zscore * 2) / 2
    if round_z <= 12.0 or round_z >= -8.0:
        return round_z

    if round_z > 12.0:
        round_z = 12.0
    if round_z < -8.0:
        round_z = -8.0

    return round_z


def get_closest_gridpoint(rxGRID, fv1, fv2):
    """
    Function to find the closest point in a grid. This is a function needed by the GridScore class to match a residue's
    sequence context to a similar context in PDB's sequences.
    """
    dlist = []
    for g1 in rxGRID.keys():
        fg1 = float(g1)
        for g2 in rxGRID[g1].keys():
            fg2 = float(g2)
            dist = sqrt((fv1 - fg1) ** 2 + (fv2 - fg2) ** 2)
            dlist.append([dist, g1, g2])
    dlist.sort()
    return dlist[0][1], dlist[0][2]


class ResidueGridScores:
    """Class to store grid scores for a sequence."""
    def __init__(self, ires: int, aa: str, n_outside_grid: int, A: float, B: float):
        self.ires = int(ires)                       # index of a residue.
        self.aa = str(aa)                           # name of a residue.
        self.n_outside_grid = int(n_outside_grid)   # number of residues that could not be matched to PDB.
        self.A = float(A)                           # biophysical feature statistics A.
        self.B = float(B)                           # biophysical feature statistics B.

    def __str__(self):
        return "%4i %1s %2i %10.8f %10.8f" % (self.ires, self.aa, self.n_outside_grid, self.A, self.B)


class GridScore:
    """
    This is the class to infer biophysical feature statistics from PDB for a given sequence. I analyzed the structures
    of the entire PDB (resolution>2.0A), and saved average frequency and standard deviation for a total of 8 biophysical
    feature for any X_N_Y residue pair. Here X is residue A, N is the number of residues in between (0-40), and Y is
    residue B. Then I break the input sequence to many X_N_Y residue pairs, and match these residue pairs to PDB.
    """
    def __init__(self, dbpath: str, tagA: str, tagB: str, max_xmer: int):
        self.dbpath = dbpath    # path of the file storing PDB statistics.
        self.tagA = tagA  # typically the name of the "short range" observation frequency
        self.tagB = tagB  # typically the name of the "long range" observation frequency
        self.PairFreqDB = {}

        # store the statistics (average and std) for all residue pairs.
        assert (exists(self.dbpath + "/PCON2.FREQS.wBOOTDEV"))
        ffile = open(self.dbpath + "/PCON2.FREQS.wBOOTDEV").readlines()
        for f in ffile:
            l = f.split()

            pair_key = l[0]  # This is the amino acid pair key (ie: H_3_P means HxxxP)

            self.PairFreqDB[pair_key] = {}

            for triplet in range((len(l) - 1) // 3):  # data is stores in blocks of 3 ie: "X_srpipi 0.035311 0.001289"
                ptype = l[1 + triplet * 3]  # name of frequency statistic associated with a given pair ie: X_srpipi
                freq = float(l[1 + triplet * 3 + 1])  # frequency
                sdev = float(l[1 + triplet * 3 + 2])  # standard deviation (from bootstrap analysis)

                self.PairFreqDB[pair_key][ptype] = [freq, sdev]

        # Each residue's biophysical impact are considered to be limited to its context (40 residues). Therefore I also
        # need to take their average statistics in different context lengths.
        assert (exists(self.dbpath + "/STEP6_PICKLES/SC_GRIDS.pickle4"))
        self.ZGridDB = pickle.load(open(self.dbpath + "/STEP6_PICKLES/SC_GRIDS.pickle4", 'rb'))

        self.xmers = []
        for n in range(max_xmer):
            self.xmers.append(n + 1)
        self.min_xmer = 1
        self.max_xmer = max_xmer

        self.AvgSdevDB = {}
        for xmer in self.xmers:
            self.AvgSdevDB[xmer] = {"LR": {}, "SR": {}}
            assert (exists(self.dbpath + "/STEP4_AVGnSDEVS/PCON2.xmer" + str(xmer)))
            PairAvgSdevFile = open(self.dbpath + "/STEP4_AVGnSDEVS/PCON2.xmer" + str(xmer)).readlines()
            for f in PairAvgSdevFile:
                l = f.split()
                self.AvgSdevDB[xmer]["SR"][l[0]] = [float(l[2]), float(l[3])]  # AVG, SDEV
                self.AvgSdevDB[xmer]["LR"][l[0]] = [float(l[5]), float(l[6])]  # AVG, SDEV

    def score_mseq_onexmer(self, mseq, use_xmer):
        """This function calculates the average statistics for one xmer (x is the window size to do summing on)."""
        # print mseq

        LR_SUMF = 0.0
        SR_SUMF = 0.0
        TOTF = 0.0

        TOTLR = 0.0
        TOTSR = 0.0

        M1 = mseq[use_xmer]

        for P in range(use_xmer):  # +1):
            Xp = P
            POS1 = use_xmer - 1 - P

            key1 = mseq[Xp] + "_" + str(POS1) + "_" + M1

            LR_SUMF += self.PairFreqDB[key1]["Y_" + self.tagB][0] * (1.0 / self.PairFreqDB[key1]["Y_" + self.tagB][1])
            SR_SUMF += self.PairFreqDB[key1]["Y_" + self.tagA][0] * (1.0 / self.PairFreqDB[key1]["Y_" + self.tagA][1])
            TOTLR += (1.0 / self.PairFreqDB[key1]["Y_" + self.tagB][1])
            TOTSR += (1.0 / self.PairFreqDB[key1]["Y_" + self.tagA][1])

        for P in range(use_xmer):
            Xp = use_xmer + 1 + P
            POS1 = P

            key1 = M1 + "_" + str(POS1) + "_" + mseq[Xp]

            LR_SUMF += self.PairFreqDB[key1]["X_" + self.tagB][0] * (1.0 / self.PairFreqDB[key1]["X_" + self.tagB][1])
            SR_SUMF += self.PairFreqDB[key1]["X_" + self.tagA][0] * (1.0 / self.PairFreqDB[key1]["X_" + self.tagA][1])
            TOTLR += (1.0 / self.PairFreqDB[key1]["X_" + self.tagB][1])
            TOTSR += (1.0 / self.PairFreqDB[key1]["X_" + self.tagA][1])

        LR_FREQ = LR_SUMF / TOTLR
        SR_FREQ = SR_SUMF / TOTSR

        return SR_FREQ, LR_FREQ

    def score_mseq_smart(self, mseq):

        assert (len(mseq) % 2 == 1)

        midpoint = int((len(mseq) - 1) / 2)

        assert (midpoint <= self.max_xmer)

        scores = {}

        frequency_sum_A = 0.0  # Typically the short range frequency (tagA)
        frequency_sum_B = 0.0  # Typically the long range frequency (tagB)

        denom_total_A = 0.0
        denom_total_B = 0.0

        mid_res_aa = mseq[midpoint]
        for P in range(midpoint):
            # Values for when mid_res is the X in X_n_Y
            cterm_position = midpoint + 1 + P
            gap_length = P
            pairdb_key = mid_res_aa + "_" + str(gap_length) + "_" + mseq[cterm_position]

            frequency_sum_A += self.PairFreqDB[pairdb_key]["X_" + self.tagA][0] \
                               * (1.0 / self.PairFreqDB[pairdb_key]["X_" + self.tagA][1])

            frequency_sum_B += self.PairFreqDB[pairdb_key]["X_" + self.tagB][0] \
                               * (1.0 / self.PairFreqDB[pairdb_key]["X_" + self.tagB][1])

            denom_total_A += (1.0 / self.PairFreqDB[pairdb_key]["X_" + self.tagA][1])
            denom_total_B += (1.0 / self.PairFreqDB[pairdb_key]["X_" + self.tagB][1])

            # Values for when mid_res is the Y in X_n_Y
            nterm_position = midpoint - P - 1
            gap_length = P
            key1Y = mseq[nterm_position] + "_" + str(gap_length) + "_" + mid_res_aa

            frequency_sum_A += self.PairFreqDB[key1Y]["Y_" + self.tagA][0] \
                               * (1.0 / self.PairFreqDB[key1Y]["Y_" + self.tagA][1])

            frequency_sum_B += self.PairFreqDB[key1Y]["Y_" + self.tagB][0] \
                               * (1.0 / self.PairFreqDB[key1Y]["Y_" + self.tagB][1])

            denom_total_A += (1.0 / self.PairFreqDB[key1Y]["Y_" + self.tagA][1])
            denom_total_B += (1.0 / self.PairFreqDB[key1Y]["Y_" + self.tagB][1])

            ######SAVE WINDOW SCORE

            if self.min_xmer <= P + 1 <= self.max_xmer:
                final_frequency_A = frequency_sum_A / denom_total_A
                final_frequency_B = frequency_sum_B / denom_total_B

                scores[P + 1] = [final_frequency_A, final_frequency_B]

        return scores

    def score_sequence(self, tagseq):
        """This is the function to generate biophysical statistical scores for the entire sequence."""
        tag = tagseq[0]
        seqref = tagseq[1]

        scoredata = []

        for nt in range(len(seqref)):

            if nt > 0 and nt + 1 < len(seqref):
                mid_res_aa = seqref[nt]

                grid_counts = [0.0, 0.0, 0.0]
                n_outside_grid = 0

                use_xmer = self.min_xmer
                mseq = seqref[nt - use_xmer:nt + use_xmer + 1]
                while len(mseq) == 2 * use_xmer + 1 and mseq.find('X') == -1 and use_xmer <= self.max_xmer:
                    use_xmer += 1
                    mseq = seqref[nt - use_xmer:nt + use_xmer + 1]
                use_xmer -= 1
                mseq = seqref[nt - use_xmer:nt + use_xmer + 1]

                avg_zscore_sr = 0.0
                avg_zscore_lr = 0.0
                zscore_n = 0.0

                if len(mseq) >= 2 * self.min_xmer + 1 and mseq.find('X') == -1:
                    all_xmer_scores = self.score_mseq_smart(mseq)
                    # try:
                    #     all_xmer_scores = self.score_mseq_smart(mseq)
                    # except:
                    #     print(tag)
                    #     print(seqref)
                    #     exit()
                    #     break

                    for XN in range(self.max_xmer - self.min_xmer + 1):
                        xmer = XN + self.min_xmer

                        if xmer in all_xmer_scores:

                            freq_sr = all_xmer_scores[xmer][0]
                            freq_lr = all_xmer_scores[xmer][1]

                            zscore_sr = (freq_sr - self.AvgSdevDB[xmer]["SR"][mid_res_aa][0]) \
                                        / self.AvgSdevDB[xmer]["SR"][mid_res_aa][1]
                            zscore_lr = (freq_lr - self.AvgSdevDB[xmer]["LR"][mid_res_aa][0]) \
                                        / self.AvgSdevDB[xmer]["LR"][mid_res_aa][1]

                            SK = make_linekey(zscore_sr)
                            LK = make_linekey(zscore_lr)

                            avg_zscore_sr += zscore_sr
                            avg_zscore_lr += zscore_lr
                            zscore_n += 1.0

                            matched_to_grid = False
                            if (SK in self.ZGridDB[mid_res_aa][xmer]):
                                if (LK in self.ZGridDB[mid_res_aa][xmer][SK]):
                                    GD = self.ZGridDB[mid_res_aa][xmer][SK][LK]
                                    grid_counts[0] += GD[0]  # Total
                                    grid_counts[1] += GD[1]  # SR
                                    grid_counts[2] += GD[2]  # LR
                                    matched_to_grid = True

                            if not matched_to_grid:
                                n_outside_grid += 1
                                SK, LK = get_closest_gridpoint(self.ZGridDB[mid_res_aa][xmer], zscore_sr, zscore_lr)
                                GD = self.ZGridDB[mid_res_aa][xmer][SK][LK]
                                grid_counts[0] += GD[0]  # Total
                                grid_counts[1] += GD[1]  # SR
                                grid_counts[2] += GD[2]  # LR

                freq_by_grid_sr = 0.0
                freq_by_grid_lr = 0.0
                if grid_counts[0] > 0:
                    freq_by_grid_sr = grid_counts[1] / grid_counts[0]
                    freq_by_grid_lr = grid_counts[2] / grid_counts[0]
                    avg_zscore_sr /= zscore_n
                    avg_zscore_lr /= zscore_n

                ostring = "%20s %5i %1s %2i %12s %8.5f %8.5f %12s %8.5f %8.5f " % \
                          ("temp", nt, mid_res_aa, n_outside_grid, self.tagA,
                           avg_zscore_sr, freq_by_grid_sr, self.tagB,
                           avg_zscore_lr, freq_by_grid_lr)

                rscore = ResidueGridScores(nt + 1, mid_res_aa, n_outside_grid, freq_by_grid_sr, freq_by_grid_lr)
                scoredata.append(rscore)
        return tag, scoredata


def readfasta(filepath):
    """Function to read a fasta file into a {tag:seq} dictionary."""
    f = open(filepath, 'r')
    seqs = {}
    onfasta, seq = "", ""
    for l in f.readlines():
        if not l.strip():
            continue
        if l[0] == '>':
            if onfasta != "" and just_canonical(seq):
                seqs[onfasta] = seq
            seq = ""
            onfasta = l.split()[0][1:]
        else:
            seq += l.split()[0]
    seqs[onfasta] = seq
    return seqs


def calculate_modified_zscore(x, a):
    """calculate the modified z-score of x against a (to account for skewed normal distribution).
    
    Args:
        x (float): raw value.
        a (np.array): background values to calculate modified z-score.

    Returns:
        [float]: modified z-score for x against a.

    """
    a_median = np.median(a)
    # print("Median: ", a_median)
    a_mean = np.mean(a)
    # print("Mean: ", a_mean)
    median_abs_dev = np.median(np.absolute(a-a_median))
    # print("median absolute deviation (MAD)", median_abs_dev)
    mean_abs_dev = np.mean(np.absolute(a-a_mean))
    # print("mean absolute deviation (MeanAD)", mean_abs_dev)

    if median_abs_dev==0:
        return (x-a_median)/(1.253314*mean_abs_dev)
    else:
        return (x-a_median)/(1.486*median_abs_dev)


def smooth_scores(scores, smooth_window):
    """get smoothed list of scores given a scores list/array and a smooth window.

    Args:
        scores ([list, np.array]): input scores.
        smooth_window ([int]): smooth window.
    Returns:
        np.array
    """
    if len(scores) < 2 * smooth_window:
        return scores
    else:
        half_window = smooth_window//2
        new_scores = [0]*len(scores)
        for i in range(len(scores)):
            if i < half_window:
                new_scores[i] = np.mean(scores[:smooth_window])
            elif i+1 > len(scores) - half_window:
                new_scores[i] = np.mean(scores[:-smooth_window])
            else:
                new_scores[i] = np.mean(scores[i-half_window:i+half_window])
        return new_scores


##################################
# Load sequences and get scores
##################################
def seqs2grids(sequences, score_db_dir):
    """
    For multiple sequences ({tag: seq} dictionary), convert to grids ({tag: grid}).
    """
    grids = {tag: {} for tag in sequences}
    for feature in feature_tagABs:
        # load GridScore database for one feature
        # print("LOADING {} DATABASE".format(feature))
        tagA, tagB = feature_tagABs[feature][0], feature_tagABs[feature][1]
        feature_grid_score = GridScore(dbpath=score_db_dir + "/{}".format(feature),
                                       tagA=tagA, tagB=tagB, max_xmer=40)
        print("CONVERTING SEQUENCES TO {} GRIDS".format(feature))
        # generate the one-feature grids for all seqs.
        for tag, seq in tqdm(sequences.items()):
            _tag, res_scores = feature_grid_score.score_sequence((tag, seq))
            feature_grid = {}
            for aa_ in canonical_amino_acids:
                feature_grid[aa_] = [[], [], []]

            for r in res_scores:
                feature_grid[r.aa][0].append(r.ires)
                feature_grid[r.aa][1].append(r.A)
                feature_grid[r.aa][2].append(r.B)

            for aa_ in feature_grid:
                feature_grid[aa_] = np.asarray(feature_grid[aa_])

            grids[tag][feature] = feature_grid
    return grids


def get_g2w_scores(grids, weight, features):
    g2w_scores = {
    'tag': [], 
    'feature': [],
    'g2w_score': []
    }
    for tag, grid in grids.items():
        for feature in feature_tagABs_new:
            for i in range(2):
                feat = feature_tagABs_new[feature][i]
                if feat in features:
                    g2w_score = grid2weight_score_sub_feature(one_feature_grid=grid[feature], 
                                                              one_feature_weight=weight[feature],
                                                              sub_feature=i,
                                                              sign=feature_signs[feat])
                    g2w_scores['tag'].append(tag)
                    g2w_scores['feature'].append(feat)
                    g2w_scores['g2w_score'].append(g2w_score)
    df = pd.DataFrame(g2w_scores)
    
    # pivot table and get g2w score sum.
    new_df = pd.pivot_table(df, 
                            values='g2w_score', 
                            index=['tag'],
                            columns=['feature'])
    new_df['{}-feature sum'.format(len(features)-1)] = new_df.sum(axis=1)
    new_df = new_df.reset_index()
    new_df = new_df[['tag'] + features]
    new_df.columns.name = None

    return new_df


def get_zscores(g2w_scores, g2w_mean_std):
    g2w_mean = pd.DataFrame(pd.DataFrame(g2w_mean_std).iloc[0, :]).T.reset_index(drop=True)
    g2w_std = pd.DataFrame(pd.DataFrame(g2w_mean_std).iloc[1, :]).T.reset_index(drop=True)

    zscores = g2w_scores[list(g2w_mean_std.keys())].sub(g2w_mean.values, axis='columns').div(g2w_std.values, axis='columns')
    zscores['tag'] = g2w_scores['tag']
    zscores = zscores[g2w_scores.columns.tolist()]
    # print(zscores)
    return zscores


def get_percentile_ranking(g2w_scores, g2w_scores_control):
    pct_ranks = {feat:[] for feat in g2w_scores.columns.tolist() \
                 if feat in g2w_scores_control.columns.tolist()}
    for feat in pct_ranks.keys():
        feat_scores, feat_scores_control = g2w_scores[feat].values, g2w_scores_control[feat].values
        for fs in feat_scores:
            pct_rank = percentileofscore(a=feat_scores_control,
                                         score=fs)
            pct_ranks[feat].append(pct_rank)
    df = pd.DataFrame(pct_ranks)
    df['tag'] = g2w_scores['tag']
    df = df[g2w_scores.columns.tolist()]
    return df


def get_modified_zscores(g2w_scores, g2w_scores_control):
    modified_zscores = {feat:[] for feat in g2w_scores.columns.tolist() \
                        if feat in g2w_scores_control.columns.tolist()}
    for feat in modified_zscores.keys():
        feat_scores, feat_scores_control = g2w_scores[feat].values, g2w_scores_control[feat].values
        for fs in feat_scores:
            modified_zscore = calculate_modified_zscore(x=fs,
                                                        a=feat_scores_control)
            modified_zscores[feat].append(modified_zscore)
    df = pd.DataFrame(modified_zscores)
    df['tag'] = g2w_scores['tag']
    df = df[g2w_scores.columns.tolist()]
    return df


def get_g2w_scores_residue_level(grids, weight, features):
    g2w_scores_residue_level = {}
    for tag, grid in grids.items():
        g2w_scores_residue_level[tag] = {}
        for feature in feature_tagABs_new:
            for i in range(2):
                feat = feature_tagABs_new[feature][i]
                if feat in features:
                    g2w_score_residue_level = grid2weight_score_residue_level_sub_feature(one_feature_grid=grid[feature],
                                                                                          one_feature_weight=weight[feature],
                                                                                          sub_feature=i,
                                                                                          sign=feature_signs[feat])
                    g2w_scores_residue_level[tag][feat] = g2w_score_residue_level

        # calculate residue-level score sum over features.
        sum_feat_name = '{}-feature sum'.format(len(features)-1)
        any_feat = features[0]
        g2w_scores_residue_level[tag][sum_feat_name] = {
            'res_type': g2w_scores_residue_level[tag][any_feat]['res_type'],
            'res_idx': g2w_scores_residue_level[tag][any_feat]['res_idx'],
            'res_score': np.array([0]*len(g2w_scores_residue_level[tag][any_feat]['res_idx'])),
        }
        for feat in features:
            if feat != sum_feat_name:
                g2w_scores_residue_level[tag][sum_feat_name]['res_score'] = tuple(
                    np.add(
                        g2w_scores_residue_level[tag][sum_feat_name]['res_score'],
                        g2w_scores_residue_level[tag][feat]['res_score']
                        )
                    )

    return g2w_scores_residue_level
                    

def get_smoothed_scores_residue_level(g2w_scores_residue_level, smooth_window=50):
    """get the residue-level scores after smoothing out. For each residue, average its score with its n closest neighbors."""
    smoothed_scores_residue_level = {
        'tag': [],
        'feature': [],
        'residue_type':[],
        'residue_idx': [],
        'score': []
    }
    for tag in g2w_scores_residue_level:
        raw_scores_res_level = g2w_scores_residue_level[tag]
        for feat in features:
            raw_scores_feature_res_level = raw_scores_res_level[feat]['res_score']
            # raw_scores_feature_sum_res_level = raw_scores_res_level['{}-feature sum'.format(len(features)-1)]['res_score']
            smoothed_scores_res_level = smooth_scores(scores=raw_scores_feature_res_level,
                                                    smooth_window=smooth_window)
            # smoothed_scores_res_level = smooth_scores(scores=raw_scores_feature_sum_res_level,
            #                                           smooth_window=smooth_window)
            for i in range(len(smoothed_scores_res_level)):
                res_type = raw_scores_res_level['{}-feature sum'.format(len(features)-1)]['res_type'][i]
                res_idx = raw_scores_res_level['{}-feature sum'.format(len(features)-1)]['res_idx'][i]
                res_smoothed_score = smoothed_scores_res_level[i]
                smoothed_scores_residue_level['tag'].append(tag)
                smoothed_scores_residue_level['feature'].append(feat)
                smoothed_scores_residue_level['residue_type'].append(res_type)
                smoothed_scores_residue_level['residue_idx'].append(res_idx)
                smoothed_scores_residue_level['score'].append(res_smoothed_score)
    df = pd.DataFrame(smoothed_scores_residue_level)
    return df
    

def get_top_n_residues_sum_score(g2w_scores_residue_level, n=100):
    """get the sum score of n top-scored residues in a sequence."""
    top_n_res_sum_score = {
        'tag': [],
        # 'feature': [],
        'top_{}_residues_sum'.format(n): []
    }
    for tag in g2w_scores_residue_level:
        raw_scores_res_level = g2w_scores_residue_level[tag]
        raw_scores_feature_sum_res_level = raw_scores_res_level['{}-feature sum'.format(len(features)-1)]['res_score']
        top_n_sum = sum(sorted(raw_scores_feature_sum_res_level)[::-1][:n])
        top_n_res_sum_score['tag'].append(tag)
        top_n_res_sum_score['top_{}_residues_sum'.format(n)].append(top_n_sum)
    df = pd.DataFrame(top_n_res_sum_score)
    return df


##################################
# run Predictor 2.0 on fasta file
#################################

def run_fasta_scorer(args):
    seqs = readfasta(args.fasta)
    grids = seqs2grids(sequences=seqs, score_db_dir=score_db_dir)
    print('CALCULATING SCORES')

    # load datasets based on model_train_base.
    final_model = final_models[args.model_train_base]

    # load the base for calculating percentile ranking and z-score.
    # 2020.12.05 - set the calculating base as human proteome.
    if args.model_train_base=='human':
        g2w_scores_base = human_g2w_scores['human']
        g2w_mean_std_base = g2w_means_stds_human['human']
    elif args.model_train_base=='PDB':
        # g2w_scores_base = PDB_g2w_scores['PDB']
        # g2w_mean_std_base = g2w_means_stds_PDB['PDB']
        g2w_scores_base = human_g2w_scores['PDB']
        g2w_mean_std_base = g2w_means_stds_human['PDB']
    else:
        # g2w_scores_base = humanPDB_g2w_scores['human+PDB']
        # g2w_mean_std_base = g2w_means_stds_humanPDB['human+PDB']
        g2w_scores_base = human_g2w_scores['human+PDB']
        g2w_mean_std_base = g2w_means_stds_human['human+PDB']
   
    # g2w_scores_human = human_g2w_scores[args.model_train_base]
    # g2w_scores_PDB = PDB_g2w_scores[args.model_train_base]
    # g2w_mean_std_human = g2w_means_stds_human[args.model_train_base]
    # g2w_mean_std_pdb = g2w_means_stds_PDB[args.model_train_base]

    # sequence-level scoring.
    if args.score_type in ['raw', 'percentile', 'zscore', 'modified_zscore', 'all']:
        raw_scores = get_g2w_scores(grids, weight=final_model, features=features)
        # output raw scores.
        if args.score_type=='raw':
            output_scores = raw_scores
        # output percentile ranking.
        if args.score_type=='percentile':
            output_scores = get_percentile_ranking(g2w_scores=raw_scores, g2w_scores_control=g2w_scores_base)
        # output z-score.
        if args.score_type=='zscore':
            output_scores = get_zscores(g2w_scores=raw_scores, g2w_mean_std=g2w_mean_std_base)
        # output modified z-score.
        if args.score_type=='modified_zscore':
            output_scores = get_modified_zscores(g2w_scores=raw_scores, g2w_scores_control=g2w_scores_base)
        # output all score types.
        if args.score_type=='all':
            tag_col = raw_scores['tag']
            output_scores_raw = raw_scores.drop(['tag'], axis=1)
            output_scores_pct = get_percentile_ranking(g2w_scores=raw_scores, g2w_scores_control=g2w_scores_base)\
                                .drop(['tag'], axis=1)
            output_scores_zscore = get_zscores(g2w_scores=raw_scores, g2w_mean_std=g2w_mean_std_base)\
                                .drop(['tag'], axis=1)
            output_scores_mzscore = get_modified_zscores(g2w_scores=raw_scores, g2w_scores_control=g2w_scores_base)\
                                .drop(['tag'], axis=1)
            output_scores_all = {
                'raw': output_scores_raw,
                'pct': output_scores_pct,
                'zscore': output_scores_zscore,
                'm_zscore': output_scores_mzscore,
                }
            result = pd.concat(output_scores_all)
            output_scores = result.unstack(level=0)
            output_scores[('tag', '')] = tag_col
            output_scores = output_scores[[('tag', '')] + [col for col in output_scores if col != ('tag', '')]]

    # residue-level scoring.
    if args.score_type in ['top100_residue_sum', 'residue_level']:
        raw_scores_residue_level = get_g2w_scores_residue_level(grids, weight=final_model, features=features)
        if args.score_type=='top100_residue_sum':
            output_scores = get_top_n_residues_sum_score(g2w_scores_residue_level=raw_scores_residue_level,
                                                         n=100)
        if args.score_type=='residue_level':
            output_scores = get_smoothed_scores_residue_level(g2w_scores_residue_level=raw_scores_residue_level,
                                                              smooth_window=50)

    if args.output_filename:
        output_scores.to_csv(args.output_filename, index=False)
    else:
        output_scores = output_scores.set_index("tag")
        pd.set_option('display.max_rows', None)
        if args.score_type=="all":
            print(output_scores.stack(-2))
        elif args.score_type in ["raw", "percentile", "zscore", "modified_zscore"]:
            print(output_scores.stack(-1))
        elif args.score_type in ["top100_residue_sum", "residue_level"]:
            print(output_scores)
        pd.set_option('display.max_rows', 30)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="run LLPhyScore on fasta files")
    parser.add_argument('--input file name', '-i', dest='fasta',
                        help=('input fasta file name'),
                        type=str)
    parser.add_argument('--output file name', '-o', dest='output_filename',
                        help=('output file name'),
                        type=str, default=None)
    parser.add_argument('--model training base', '-m', dest='model_train_base',
                        help=('training base of the model'),
                        type=str, default='human+PDB', choices=['human', 'PDB', 'human+PDB'])
    parser.add_argument('--score type', '-s', dest='score_type',
                        help=('type of score for 8 features'),
                        type=str, default='percentile', choices=['raw', 'percentile', 'zscore', 'modified_zscore', 'all',\
                                                                 'top100_residue_sum', 'residue_level'])
    args = parser.parse_args()
    run_fasta_scorer(args)